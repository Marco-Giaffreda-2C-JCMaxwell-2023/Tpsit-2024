const express=require('express')
const session=require('express-session')
const bodyParser=require('body-parser')
const fs=require('fs')
const path=require('path')

const app=express()
const PORT=3000

app.use(bodyParser.urlencoded({extended:true}))
app.use(express.static(path.join(__dirname,'public')))
app.use(session({secret:'socialpostit',resave:false,saveUninitialized:true}))
app.set('view engine','ejs')
app.set('views',path.join(__dirname,'views'))

const UTENTI='./utenti.json'
const POST='./post.json'

function checkAuth(req,res,next){
  if(req.session.user)next()
  else res.redirect('/login')
}

app.get('/',(req,res)=>{
  const post=JSON.parse(fs.readFileSync(POST))
  res.render('pages/home',{user:req.session.user,post})
})

app.get('/signup',(req,res)=>{res.render('pages/signup',{msg:''})})
app.post('/signup',(req,res)=>{
  const utenti=JSON.parse(fs.readFileSync(UTENTI))
  const {username,password}=req.body
  if(utenti.find(u=>u.username==username))
    return res.render('pages/signup',{msg:'Username esistente'})
  utenti.push({username,password})
  fs.writeFileSync(UTENTI,JSON.stringify(utenti,null,2))
  res.redirect('/login')
})

app.get('/login',(req,res)=>{res.render('pages/login',{msg:''})})
app.post('/login',(req,res)=>{
  const utenti=JSON.parse(fs.readFileSync(UTENTI))
  const {username,password}=req.body
  const user=utenti.find(u=>u.username==username && u.password==password)
  if(!user)return res.render('pages/login',{msg:'Credenziali errate'})
  req.session.user=username
  res.redirect('/')
})

app.get('/logout',(req,res)=>{
  req.session.destroy(()=>res.redirect('/'))
})

app.get('/nuovoPost',checkAuth,(req,res)=>{
  res.render('pages/post',{user:req.session.user,msg:''})
})
app.post('/nuovoPost',checkAuth,(req,res)=>{
  const {titolo,testo,colore}=req.body
  const post=JSON.parse(fs.readFileSync(POST))
  post.unshift({autore:req.session.user,titolo,testo,colore,data:new Date().toLocaleString()})
  fs.writeFileSync(POST,JSON.stringify(post,null,2))
  res.redirect('/')
})

app.listen(PORT,()=>console.log('Server avviato su http://localhost:'+PORT))